package vocealuga.dao;

import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;

/**
 *
 * @author Fernanda Muniz
 */
public class ModuloConexao {
    //Metodo responsavel por estabelecer a conexão com o banco.
    public static Connection conector() {
        
        java.sql.Connection conexao = null;
        // A linha abaixo chama o drive importado para biblioteca.
        String drive = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/locadoravcluga";
        String user = "root";
        String password = "";
        
        try {
            Class.forName(drive);
            conexao = DriverManager.getConnection(url, user, password);
            return conexao;
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }
      public Array CarregaDados(){
        ArrayList array = new ArrayList();
        array.add("teste1");
        array.add("teste2");
        array.add("teste3");
        array.add("teste4");
        array.add("teste5");
        array.add("teste6");
        for (int i = 0; i < array.size(); i++) {
                System.out.println(array.get(i));
        }
        return (Array) array;
    }
}
