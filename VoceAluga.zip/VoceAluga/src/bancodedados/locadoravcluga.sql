/* 
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
DROP DATABASE locadoravcluga;
CREATE DATABASE locadoravcluga;
USE locadoravcluga;

DROP TABLE IF EXISTS  usuarios;
CREATE TABLE `usuarios` (
	nome varchar(70) NOT NULL,
	telefone text,
	cpf varchar(14) DEFAULT NULL,
	email varchar(20) DEFAULT NULL,
	cep  varchar(12),
	endereco text,
	numero int,
	bairro text,
	cidade text,
	estado text,
	login text,
	senha text,
	cargo text,
	PRIMARY KEY (`nome`),
	UNIQUE KEY `cpf` (`cpf`)
)ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;


INSERT INTO `usuarios`(`nome`, `telefone`, `cpf`, `email`, `cep`, `endereco`, `numero`, `bairro`, `cidade`, `estado`, `login`, `senha`, `cargo`) VALUES ('fernanda','21996897737','170.561.577-51','fernandinha@hotmail.com','26060750','rua projetada c','48','figueiras','nova iguacu','RJ','admin','admin','admin');



DROP TABLE IF EXISTS `cad_veiculos`;
CREATE TABLE `cad_veiculos` (
	cod bigint(20) NOT NULL AUTO_INCREMENT,
	marca text  NOT NULL,
	modelo text  NOT NULL,
	ano varchar(4) DEFAULT NULL,
	placa varchar(8) DEFAULT NULL,
	cor varchar(11),
	categoria text,
	situacao text,
	arquivo longblob,
	PRIMARY KEY (`cod`),
	UNIQUE KEY `cod` (`cod`),
	UNIQUE KEY `placa_UNIQUE` (`placa`)
	
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS  `clientes`;
CREATE TABLE `clientes` (
	nome varchar(70) NOT NULL,
	cpf varchar(14) DEFAULT NULL,
	cep  varchar(12) NOT NULL,
	endereco text,
	numero int,
	cidade text,
	bairro text,
	estado text,
	email text,
	telefone text,
	UNIQUE KEY `cpf` (`cpf`)
)ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

CREATE TABLE `vendas` (
	codvenda bigint(20)  NOT NULL,
	cod bigint(20)  DEFAULT NULL,
	cpfcliente varchar(14) DEFAULT NULL,
	recibo bigint(20)  DEFAULT NULL,
	licenciamento  bigint(20)  DEFAULT NULL,
	ipva bigint(20)  DEFAULT NULL,
	seguro bigint(20)  DEFAULT NULL,
	manual bigint(20)  DEFAULT NULL,
	chavereserva bigint(20)  DEFAULT NULL,
	liberacao varchar(20)  DEFAULT NULL,
	porteobg varchar(20)  DEFAULT NULL,
	custo varchar(20) DEFAULT NULL,
	limpeza varchar(20)  DEFAULT NULL,
	mecanica varchar(20)  DEFAULT NULL,
	revisao varchar(20)  DEFAULT NULL,
	custototal varchar(20)  DEFAULT NULL,
	valorvenda varchar(20)  DEFAULT NULL,
	PRIMARY KEY (`codvenda`),
	UNIQUE KEY `codvenda` (`codvenda`),
	KEY `venda_fk0` (`cod`),
	CONSTRAINT `venda_ibfk_1` FOREIGN KEY (`cod`) REFERENCES `cad_veiculos` (`cod`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
		